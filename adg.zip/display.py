WIDTH   = 62
DIVIDER = "─" * WIDTH
HEAVY   = "═" * WIDTH


def _center(text):
    return text.center(WIDTH)


def print_divider(heavy=False):
    print(HEAVY if heavy else DIVIDER)


def print_header(title):
    print()
    print_divider(heavy=True)
    print(_center(f"  {title}  "))
    print_divider(heavy=True)


def print_section(title):
    print()
    print(f"  ▸ {title}")
    print_divider()


def print_numbered_menu(items):
    for idx, item in enumerate(items, start=1):
        print(f"    {idx}. {item}")
    print()


def print_passenger_breakdown(passenger_num, name, age, breakdown,
                               baggage_weight, free_baggage):
    print_section(f"Passenger {passenger_num}: {name}  (Age {age})")

    def row(label, amount, sign=""):
        amount_str = f"{sign}INR {amount:,.2f}"
        print(f"    {label:<38} {amount_str:>16}")

    row("Base slab fare", breakdown["slab_fare"])
    if breakdown["after_senior"] != breakdown["slab_fare"]:
        discount = breakdown["slab_fare"] - breakdown["after_senior"]
        row("Senior citizen discount (−40%)", discount, sign="−")
    row("After train premium", breakdown["after_train"])
    row("After class premium", breakdown["after_class"])

    if breakdown["baggage_fee"] > 0:
        extra_kg = baggage_weight - free_baggage
        row(f"Excess baggage ({extra_kg:.1f} kg × INR 15)", breakdown["baggage_fee"], sign="+")
    else:
        print(f"    {'Baggage: within free allowance':<38} {'—':>16}")

    print_divider()
    row("Passenger Total", breakdown["total"])


def print_booking_summary(origin, destination, distance_km, train_name,
                           travel_class, travel_hours, travel_minutes,
                           passenger_fares, subtotal, promo_code,
                           promo_discount, grand_total):
    print_header("BOOKING CONFIRMATION")

    print_section("Journey Details")
    print(f"    {'Route':<20} {origin}  →  {destination}")
    print(f"    {'Distance':<20} {distance_km:,} km")
    print(f"    {'Train Type':<20} {train_name}")
    print(f"    {'Travel Class':<20} {travel_class}")
    print(f"    {'Est. Travel Time':<20} {travel_hours}h {travel_minutes}m")

    for i, pax in enumerate(passenger_fares, start=1):
        print_passenger_breakdown(
            passenger_num  = i,
            name           = pax["name"],
            age            = pax["age"],
            breakdown      = pax["breakdown"],
            baggage_weight = pax["baggage_weight"],
            free_baggage   = pax["free_baggage"],
        )

    print_section("Payment Summary")

    def row(label, amount, sign=""):
        amount_str = f"{sign}INR {amount:,.2f}"
        print(f"    {label:<38} {amount_str:>16}")

    row("Subtotal", subtotal)
    if promo_code and promo_discount > 0:
        row(f"Promo Code ({promo_code})", promo_discount, sign="−")

    print_divider(heavy=True)
    row("GRAND TOTAL", grand_total)
    print_divider(heavy=True)
    print()
    print(_center("Thank you for booking with RailBook!"))
    print()
