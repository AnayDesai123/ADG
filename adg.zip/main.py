import routes
import fare
import display
import input_helpers


def select_origin():
    display.print_section("Select Origin City")
    display.print_numbered_menu(routes.CITIES)
    idx = input_helpers.get_menu_choice(routes.CITIES, "  Enter origin number: ")
    return routes.CITIES[idx - 1]


def select_destination(origin):
    reachable = [
        city for city in routes.CITIES
        if city != origin and routes.get_distance(origin, city) is not None
    ]
    display.print_section("Select Destination City")
    display.print_numbered_menu(reachable)
    idx = input_helpers.get_menu_choice(reachable, "  Enter destination number: ")
    return reachable[idx - 1]


def select_train():
    display.print_section("Select Train Type")
    for i, name in enumerate(routes.TRAIN_TYPE_NAMES, start=1):
        info = routes.get_train_info(name)
        print(f"    {i}. {name:<20}  Speed: {info['speed_kmph']} km/h")
    print()
    idx = input_helpers.get_menu_choice(routes.TRAIN_TYPE_NAMES, "  Enter train number: ")
    return routes.TRAIN_TYPE_NAMES[idx - 1]


def select_class():
    display.print_section("Select Travel Class")
    for i, name in enumerate(routes.TRAVEL_CLASS_NAMES, start=1):
        info = routes.get_class_info(name)
        print(f"    {i}. {name:<15}  "
              f"Fare multiplier: {info['fare_multiplier']}×  |  "
              f"Free baggage: {info['free_baggage_kg']} kg")
    print()
    idx = input_helpers.get_menu_choice(routes.TRAVEL_CLASS_NAMES, "  Enter class number: ")
    return routes.TRAVEL_CLASS_NAMES[idx - 1]


def collect_all_passengers(count, travel_class, free_baggage_kg):
    passengers = []
    display.print_section("Passenger Details")
    for i in range(1, count + 1):
        pax = input_helpers.collect_passenger_details(i)
        passengers.append(pax)
    display.print_section("Baggage Declaration")
    for pax in passengers:
        pax["baggage_weight"] = input_helpers.collect_baggage_weight(
            pax["name"], free_baggage_kg, travel_class
        )
    return passengers


def calculate_all_fares(passengers, distance_km, train_info, class_info):
    passenger_fares = []
    subtotal = 0.0
    for pax in passengers:
        breakdown = fare.calculate_passenger_fare(
            distance_km       = distance_km,
            age               = pax["age"],
            train_premium     = train_info["premium"],
            class_multiplier  = class_info["fare_multiplier"],
            baggage_weight_kg = pax["baggage_weight"],
            free_baggage_kg   = class_info["free_baggage_kg"],
            flat_surcharge    = train_info["surcharge"],
        )
        subtotal += breakdown["total"]
        passenger_fares.append({
            "name":          pax["name"],
            "age":           pax["age"],
            "baggage_weight":pax["baggage_weight"],
            "free_baggage":  class_info["free_baggage_kg"],
            "breakdown":     breakdown,
        })
    return passenger_fares, subtotal


def collect_promo(subtotal):
    display.print_section("Promo Code")
    raw_code = input_helpers.get_optional_string(
        "  Enter promo code (leave blank to skip): "
    )
    if not raw_code:
        return None, 0.0, subtotal
    promo_info = routes.get_promo_info(raw_code)
    if promo_info is None:
        print(f"  ✗ '{raw_code}' is not a valid promo code. Proceeding without discount.")
        return None, 0.0, subtotal
    grand_total     = fare.apply_promo_discount(subtotal, promo_info)
    discount_amount = subtotal - grand_total
    print(f"  ✓ Promo code '{raw_code}' applied! You save INR {discount_amount:,.2f}.")
    return raw_code, discount_amount, grand_total


def run_booking():
    display.print_header("RAILWAY TICKET BOOKING SYSTEM")

    origin      = select_origin()
    destination = select_destination(origin)
    distance_km = routes.get_distance(origin, destination)
    train_name  = select_train()
    train_info  = routes.get_train_info(train_name)
    class_name  = select_class()
    class_info  = routes.get_class_info(class_name)

    travel_hours, travel_minutes = fare.calculate_travel_time(
        distance_km, train_info["speed_kmph"]
    )

    passenger_count = input_helpers.get_positive_int(
        "\n  Number of passengers (1–6): ", min_val=1, max_val=6
    )
    passengers = collect_all_passengers(
        passenger_count, class_name, class_info["free_baggage_kg"]
    )

    passenger_fares, subtotal = calculate_all_fares(
        passengers, distance_km, train_info, class_info
    )

    promo_code, promo_discount, grand_total = collect_promo(subtotal)

    display.print_booking_summary(
        origin          = origin,
        destination     = destination,
        distance_km     = distance_km,
        train_name      = train_name,
        travel_class    = class_name,
        travel_hours    = travel_hours,
        travel_minutes  = travel_minutes,
        passenger_fares = passenger_fares,
        subtotal        = subtotal,
        promo_code      = promo_code,
        promo_discount  = promo_discount,
        grand_total     = grand_total,
    )


def main():
    while True:
        run_booking()
        display.print_divider()
        again = input("  Book another ticket? (y/n): ").strip().lower()
        if again != "y":
            print("\n  Goodbye! Safe travels.\n")
            break


if __name__ == "__main__":
    main()
