BASE_FARE            = 100.0
SLAB_RATE_TIER1      = 1.00
SLAB_RATE_TIER2      = 0.80
SLAB_RATE_TIER3      = 0.60
TIER1_LIMIT          = 100
TIER2_LIMIT          = 300
SENIOR_CITIZEN_AGE   = 60
SENIOR_DISCOUNT_RATE = 0.40
EXCESS_BAGGAGE_RATE  = 15.0


def calculate_slab_fare(distance_km):
    fare = BASE_FARE
    if distance_km <= TIER1_LIMIT:
        fare += distance_km * SLAB_RATE_TIER1
    elif distance_km <= TIER2_LIMIT:
        fare += TIER1_LIMIT * SLAB_RATE_TIER1
        fare += (distance_km - TIER1_LIMIT) * SLAB_RATE_TIER2
    else:
        fare += TIER1_LIMIT * SLAB_RATE_TIER1
        fare += (TIER2_LIMIT - TIER1_LIMIT) * SLAB_RATE_TIER2
        fare += (distance_km - TIER2_LIMIT) * SLAB_RATE_TIER3
    return fare


def apply_senior_discount(fare, age):
    if age > SENIOR_CITIZEN_AGE:
        fare *= (1.0 - SENIOR_DISCOUNT_RATE)
    return fare


def apply_train_premium(fare, train_premium):
    return fare * train_premium


def apply_class_premium(fare, class_multiplier):
    return fare * class_multiplier


def calculate_excess_baggage_fee(declared_weight_kg, free_allowance_kg):
    excess = declared_weight_kg - free_allowance_kg
    if excess > 0:
        return excess * EXCESS_BAGGAGE_RATE
    return 0.0


def apply_flat_surcharge(fare, surcharge):
    return fare + surcharge


def calculate_passenger_fare(distance_km, age, train_premium, class_multiplier,
                              baggage_weight_kg, free_baggage_kg, flat_surcharge):
    step1 = calculate_slab_fare(distance_km)
    step2 = apply_senior_discount(step1, age)
    step3 = apply_train_premium(step2, train_premium)
    step4 = apply_class_premium(step3, class_multiplier)
    baggage_fee = calculate_excess_baggage_fee(baggage_weight_kg, free_baggage_kg)
    step5 = step4 + baggage_fee
    step6 = apply_flat_surcharge(step5, flat_surcharge)
    return {
        "slab_fare":    step1,
        "after_senior": step2,
        "after_train":  step3,
        "after_class":  step4,
        "baggage_fee":  baggage_fee,
        "total":        step6,
    }


def apply_promo_discount(subtotal, promo_info):
    discount_type  = promo_info["type"]
    discount_value = promo_info["value"]
    if discount_type == "percent":
        discounted = subtotal * (1.0 - discount_value / 100.0)
    elif discount_type == "flat":
        discounted = subtotal - discount_value
    else:
        discounted = subtotal
    return max(discounted, 0.0)


def calculate_travel_time(distance_km, speed_kmph):
    total_minutes = round((distance_km / speed_kmph) * 60)
    return divmod(total_minutes, 60)
