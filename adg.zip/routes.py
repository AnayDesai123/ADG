ROUTE_DISTANCES = {
    frozenset({"New Delhi", "Mumbai"}):    1460,
    frozenset({"New Delhi", "Kolkata"}):   1525,
    frozenset({"New Delhi", "Chennai"}):   2200,
    frozenset({"New Delhi", "Hyderabad"}): 1670,
    frozenset({"Mumbai", "Kolkata"}):      1970,
    frozenset({"Mumbai", "Chennai"}):      1300,
    frozenset({"Mumbai", "Hyderabad"}):     711,
    frozenset({"Kolkata", "Chennai"}):     1200,
    frozenset({"Kolkata", "Hyderabad"}):   1600,
    frozenset({"Chennai", "Hyderabad"}):    633,
}

CITIES = [
    "New Delhi",
    "Mumbai",
    "Kolkata",
    "Chennai",
    "Hyderabad",
]

TRAIN_TYPES = {
    "Superfast":      {"speed_kmph": 120, "premium": 1.50, "surcharge": 100},
    "Express":        {"speed_kmph": 110, "premium": 1.25, "surcharge":  50},
    "Fast Passenger": {"speed_kmph":  90, "premium": 1.00, "surcharge":   0},
}

TRAIN_TYPE_NAMES = ["Superfast", "Express", "Fast Passenger"]

TRAVEL_CLASSES = {
    "Sleeper":   {"fare_multiplier": 1.0, "free_baggage_kg": 20},
    "AC 3-Tier": {"fare_multiplier": 1.5, "free_baggage_kg": 30},
    "AC 2-Tier": {"fare_multiplier": 2.0, "free_baggage_kg": 40},
}

TRAVEL_CLASS_NAMES = ["Sleeper", "AC 3-Tier", "AC 2-Tier"]

PROMO_CODES = {
    "ADG20":     {"type": "percent", "value": 20},
    "WINTER500": {"type": "flat",    "value": 500},
}


def get_distance(origin, destination):
    return ROUTE_DISTANCES.get(frozenset({origin, destination}))


def get_train_info(train_name):
    return TRAIN_TYPES.get(train_name)


def get_class_info(class_name):
    return TRAVEL_CLASSES.get(class_name)


def get_promo_info(code):
    return PROMO_CODES.get(code)
