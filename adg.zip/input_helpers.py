def get_positive_int(prompt, min_val=1, max_val=None):
    while True:
        raw = input(prompt).strip()
        if not raw.lstrip("-").isdigit():
            print(f"    ✗ Please enter a whole number (got: {raw!r}).")
            continue
        value = int(raw)
        if value < min_val:
            print(f"    ✗ Value must be at least {min_val}.")
            continue
        if max_val is not None and value > max_val:
            print(f"    ✗ Value must be at most {max_val}.")
            continue
        return value


def get_positive_float(prompt, min_val=0.01):
    while True:
        raw = input(prompt).strip()
        try:
            value = float(raw)
        except ValueError:
            print(f"    ✗ Please enter a numeric value (got: {raw!r}).")
            continue
        if value < min_val:
            print("    ✗ Value must be greater than 0.")
            continue
        return value


def get_menu_choice(items, prompt="Enter choice: "):
    return get_positive_int(prompt, min_val=1, max_val=len(items))


def get_non_empty_string(prompt):
    while True:
        value = input(prompt).strip()
        if value:
            return value
        print("    ✗ Input cannot be empty. Please try again.")


def get_optional_string(prompt):
    return input(prompt).strip()


def collect_passenger_details(passenger_num):
    print(f"\n  Passenger {passenger_num} Details")
    print("  " + "─" * 40)
    name = get_non_empty_string("    Full Name         : ")
    age  = get_positive_int(    "    Age (years)       : ", min_val=1, max_val=120)
    return {"name": name, "age": age, "baggage_weight": 0.0}


def collect_baggage_weight(passenger_name, free_allowance_kg, travel_class):
    print(f"\n    Baggage for {passenger_name}"
          f"  (free allowance: {free_allowance_kg} kg in {travel_class})")
    return get_positive_float("    Declared weight (kg): ")
